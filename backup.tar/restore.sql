--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "Coffer";
--
-- Name: Coffer; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Coffer" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Hungarian_Hungary.1250';


ALTER DATABASE "Coffer" OWNER TO postgres;

\unrestrict (null)
\connect "Coffer"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attributes (
    id integer NOT NULL,
    collection_type_id integer NOT NULL,
    name character varying(20) NOT NULL,
    "primary" boolean DEFAULT false NOT NULL,
    item_options_id integer,
    data_type integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.attributes OWNER TO postgres;

--
-- Name: attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attributes_id_seq OWNER TO postgres;

--
-- Name: attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attributes_id_seq OWNED BY public.attributes.id;


--
-- Name: collection_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.collection_types (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text NOT NULL,
    color character varying(20) NOT NULL,
    icon character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.collection_types OWNER TO postgres;

--
-- Name: collection_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.collection_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collection_types_id_seq OWNER TO postgres;

--
-- Name: collection_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.collection_types_id_seq OWNED BY public.collection_types.id;


--
-- Name: collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.collections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    collection_type_id integer NOT NULL,
    name character varying(100) NOT NULL,
    image character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    description text
);


ALTER TABLE public.collections OWNER TO postgres;

--
-- Name: follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    collection_id uuid NOT NULL,
    followed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.follows OWNER TO postgres;

--
-- Name: item_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_attributes (
    id integer NOT NULL,
    item_id uuid NOT NULL,
    attribute_id integer NOT NULL,
    value_string text,
    value_number integer,
    value_date date,
    value_boolean boolean
);


ALTER TABLE public.item_attributes OWNER TO postgres;

--
-- Name: item_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_attributes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_attributes_id_seq OWNER TO postgres;

--
-- Name: item_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_attributes_id_seq OWNED BY public.item_attributes.id;


--
-- Name: item_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid,
    user_id uuid NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.item_messages OWNER TO postgres;

--
-- Name: item_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_options (
    id integer NOT NULL,
    option_ids text NOT NULL,
    option_labels text NOT NULL
);


ALTER TABLE public.item_options OWNER TO postgres;

--
-- Name: item_options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_options_id_seq OWNER TO postgres;

--
-- Name: item_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_options_id_seq OWNED BY public.item_options.id;


--
-- Name: item_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_tags (
    id integer NOT NULL,
    item_id uuid NOT NULL,
    tag text NOT NULL
);


ALTER TABLE public.item_tags OWNER TO postgres;

--
-- Name: item_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.item_tags_id_seq OWNER TO postgres;

--
-- Name: item_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_tags_id_seq OWNED BY public.item_tags.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    collection_id uuid NOT NULL,
    description text,
    quantity integer DEFAULT 1 NOT NULL,
    image character varying(100) NOT NULL,
    acquired_at timestamp without time zone DEFAULT now(),
    private_note text
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: offer_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offer_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    offer_id uuid NOT NULL,
    item_id uuid
);


ALTER TABLE public.offer_items OWNER TO postgres;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trade_id uuid NOT NULL,
    user_id uuid NOT NULL,
    money_offer numeric(10,2),
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT offers_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'rejected'::text, 'accepted'::text, 'revertByCreator'::text, 'revertByOfferer'::text, 'traded'::text])))
);


ALTER TABLE public.offers OWNER TO postgres;

--
-- Name: reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    item_id uuid NOT NULL,
    liked boolean DEFAULT false NOT NULL,
    rarity integer,
    CONSTRAINT reactions_rarity_check CHECK (((rarity >= 1) AND (rarity <= 5)))
);


ALTER TABLE public.reactions OWNER TO postgres;

--
-- Name: trade_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trade_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trade_id uuid NOT NULL,
    item_id uuid
);


ALTER TABLE public.trade_items OWNER TO postgres;

--
-- Name: trade_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trade_reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trade_id uuid NOT NULL,
    reviewer_id uuid,
    reviewee_id uuid NOT NULL,
    rating boolean NOT NULL,
    comment text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trade_reviews OWNER TO postgres;

--
-- Name: trades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    want_description text,
    money_requested numeric(10,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.trades OWNER TO postgres;

--
-- Name: user_contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    value text NOT NULL,
    link text,
    created_at timestamp without time zone DEFAULT now(),
    platform integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_contacts OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    provider_user_id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    country character varying(20) NOT NULL,
    avatar text,
    role integer DEFAULT 0 NOT NULL,
    summary text,
    CONSTRAINT users_provider_check CHECK ((provider = ANY (ARRAY['google'::text, 'github'::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes ALTER COLUMN id SET DEFAULT nextval('public.attributes_id_seq'::regclass);


--
-- Name: collection_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collection_types ALTER COLUMN id SET DEFAULT nextval('public.collection_types_id_seq'::regclass);


--
-- Name: item_attributes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attributes ALTER COLUMN id SET DEFAULT nextval('public.item_attributes_id_seq'::regclass);


--
-- Name: item_options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_options ALTER COLUMN id SET DEFAULT nextval('public.item_options_id_seq'::regclass);


--
-- Name: item_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tags ALTER COLUMN id SET DEFAULT nextval('public.item_tags_id_seq'::regclass);


--
-- Data for Name: attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attributes (id, collection_type_id, name, "primary", item_options_id, data_type) FROM stdin;
\.
COPY public.attributes (id, collection_type_id, name, "primary", item_options_id, data_type) FROM '$$PATH$$/5130.dat';

--
-- Data for Name: collection_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.collection_types (id, name, description, color, icon, created_at) FROM stdin;
\.
COPY public.collection_types (id, name, description, color, icon, created_at) FROM '$$PATH$$/5127.dat';

--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.collections (id, user_id, collection_type_id, name, image, created_at, description) FROM stdin;
\.
COPY public.collections (id, user_id, collection_type_id, name, image, created_at, description) FROM '$$PATH$$/5128.dat';

--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follows (id, user_id, collection_id, followed_at) FROM stdin;
\.
COPY public.follows (id, user_id, collection_id, followed_at) FROM '$$PATH$$/5139.dat';

--
-- Data for Name: item_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_attributes (id, item_id, attribute_id, value_string, value_number, value_date, value_boolean) FROM stdin;
\.
COPY public.item_attributes (id, item_id, attribute_id, value_string, value_number, value_date, value_boolean) FROM '$$PATH$$/5133.dat';

--
-- Data for Name: item_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_messages (id, item_id, user_id, message, created_at) FROM stdin;
\.
COPY public.item_messages (id, item_id, user_id, message, created_at) FROM '$$PATH$$/5146.dat';

--
-- Data for Name: item_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_options (id, option_ids, option_labels) FROM stdin;
\.
COPY public.item_options (id, option_ids, option_labels) FROM '$$PATH$$/5137.dat';

--
-- Data for Name: item_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_tags (id, item_id, tag) FROM stdin;
\.
COPY public.item_tags (id, item_id, tag) FROM '$$PATH$$/5135.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, collection_id, description, quantity, image, acquired_at, private_note) FROM stdin;
\.
COPY public.items (id, collection_id, description, quantity, image, acquired_at, private_note) FROM '$$PATH$$/5131.dat';

--
-- Data for Name: offer_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offer_items (id, offer_id, item_id) FROM stdin;
\.
COPY public.offer_items (id, offer_id, item_id) FROM '$$PATH$$/5144.dat';

--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offers (id, trade_id, user_id, money_offer, status, created_at, updated_at) FROM stdin;
\.
COPY public.offers (id, trade_id, user_id, money_offer, status, created_at, updated_at) FROM '$$PATH$$/5143.dat';

--
-- Data for Name: reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reactions (id, user_id, item_id, liked, rarity) FROM stdin;
\.
COPY public.reactions (id, user_id, item_id, liked, rarity) FROM '$$PATH$$/5138.dat';

--
-- Data for Name: trade_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trade_items (id, trade_id, item_id) FROM stdin;
\.
COPY public.trade_items (id, trade_id, item_id) FROM '$$PATH$$/5142.dat';

--
-- Data for Name: trade_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trade_reviews (id, trade_id, reviewer_id, reviewee_id, rating, comment, created_at) FROM stdin;
\.
COPY public.trade_reviews (id, trade_id, reviewer_id, reviewee_id, rating, comment, created_at) FROM '$$PATH$$/5145.dat';

--
-- Data for Name: trades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trades (id, user_id, title, description, want_description, money_requested, created_at, updated_at) FROM stdin;
\.
COPY public.trades (id, user_id, title, description, want_description, money_requested, created_at, updated_at) FROM '$$PATH$$/5141.dat';

--
-- Data for Name: user_contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_contacts (id, user_id, value, link, created_at, platform) FROM stdin;
\.
COPY public.user_contacts (id, user_id, value, link, created_at, platform) FROM '$$PATH$$/5140.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, provider, provider_user_id, name, email, created_at, country, avatar, role, summary) FROM stdin;
\.
COPY public.users (id, provider, provider_user_id, name, email, created_at, country, avatar, role, summary) FROM '$$PATH$$/5125.dat';

--
-- Name: attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attributes_id_seq', 6, true);


--
-- Name: collection_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.collection_types_id_seq', 2, true);


--
-- Name: item_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_attributes_id_seq', 68, true);


--
-- Name: item_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_options_id_seq', 1, true);


--
-- Name: item_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_tags_id_seq', 49, true);


--
-- Name: attributes attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes
    ADD CONSTRAINT attributes_pkey PRIMARY KEY (id);


--
-- Name: collection_types collection_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collection_types
    ADD CONSTRAINT collection_types_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: follows follows_user_id_collection_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_user_id_collection_id_key UNIQUE (user_id, collection_id);


--
-- Name: item_attributes item_attributes_item_id_attribute_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attributes
    ADD CONSTRAINT item_attributes_item_id_attribute_id_key UNIQUE (item_id, attribute_id);


--
-- Name: item_attributes item_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attributes
    ADD CONSTRAINT item_attributes_pkey PRIMARY KEY (id);


--
-- Name: item_messages item_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_messages
    ADD CONSTRAINT item_messages_pkey PRIMARY KEY (id);


--
-- Name: item_options item_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_options
    ADD CONSTRAINT item_options_pkey PRIMARY KEY (id);


--
-- Name: item_tags item_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tags
    ADD CONSTRAINT item_tags_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: offer_items offer_items_offer_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_items
    ADD CONSTRAINT offer_items_offer_id_item_id_key UNIQUE (offer_id, item_id);


--
-- Name: offer_items offer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_items
    ADD CONSTRAINT offer_items_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: offers offers_trade_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_trade_id_user_id_key UNIQUE (trade_id, user_id);


--
-- Name: reactions reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_pkey PRIMARY KEY (id);


--
-- Name: reactions reactions_user_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_user_id_item_id_key UNIQUE (user_id, item_id);


--
-- Name: trade_items trade_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_items
    ADD CONSTRAINT trade_items_pkey PRIMARY KEY (id);


--
-- Name: trade_items trade_items_trade_id_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_items
    ADD CONSTRAINT trade_items_trade_id_item_id_key UNIQUE (trade_id, item_id);


--
-- Name: trade_reviews trade_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_reviews
    ADD CONSTRAINT trade_reviews_pkey PRIMARY KEY (id);


--
-- Name: trade_reviews trade_reviews_trade_id_reviewer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_reviews
    ADD CONSTRAINT trade_reviews_trade_id_reviewer_id_key UNIQUE (trade_id, reviewer_id);


--
-- Name: trades trades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_pkey PRIMARY KEY (id);


--
-- Name: user_contacts user_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_contacts_pkey PRIMARY KEY (id);


--
-- Name: user_contacts user_id_platform_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_id_platform_key UNIQUE (user_id, platform);


--
-- Name: users users_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_name_key UNIQUE (name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_provider_provider_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_provider_provider_user_id_key UNIQUE (provider, provider_user_id);


--
-- Name: idx_collections_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_collections_name_trgm ON public.collections USING gin (name public.gin_trgm_ops);


--
-- Name: idx_item_tags_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_item_tags_tag ON public.item_tags USING btree (tag);


--
-- Name: idx_itemtags_tag_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_itemtags_tag_trgm ON public.item_tags USING gin (tag public.gin_trgm_ops);


--
-- Name: idx_user_name_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_name_trgm ON public.users USING gin (name public.gin_trgm_ops);


--
-- Name: attributes attributes_collection_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes
    ADD CONSTRAINT attributes_collection_type_id_fkey FOREIGN KEY (collection_type_id) REFERENCES public.collection_types(id) ON DELETE CASCADE;


--
-- Name: collections collections_collection_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_collection_type_id_fkey FOREIGN KEY (collection_type_id) REFERENCES public.collection_types(id);


--
-- Name: collections collections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: attributes fk_attributes_item_options; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attributes
    ADD CONSTRAINT fk_attributes_item_options FOREIGN KEY (item_options_id) REFERENCES public.item_options(id) ON DELETE SET NULL;


--
-- Name: follows follows_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: follows follows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: item_attributes item_attributes_attribute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attributes
    ADD CONSTRAINT item_attributes_attribute_id_fkey FOREIGN KEY (attribute_id) REFERENCES public.attributes(id) ON DELETE CASCADE;


--
-- Name: item_attributes item_attributes_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_attributes
    ADD CONSTRAINT item_attributes_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: item_messages item_messages_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_messages
    ADD CONSTRAINT item_messages_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: item_messages item_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_messages
    ADD CONSTRAINT item_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: item_tags item_tags_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tags
    ADD CONSTRAINT item_tags_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: items items_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: offer_items offer_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_items
    ADD CONSTRAINT offer_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: offer_items offer_items_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offer_items
    ADD CONSTRAINT offer_items_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.offers(id) ON DELETE CASCADE;


--
-- Name: offers offers_trade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_trade_id_fkey FOREIGN KEY (trade_id) REFERENCES public.trades(id) ON DELETE CASCADE;


--
-- Name: offers offers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: trade_items trade_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_items
    ADD CONSTRAINT trade_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id) ON DELETE SET NULL;


--
-- Name: trade_items trade_items_trade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_items
    ADD CONSTRAINT trade_items_trade_id_fkey FOREIGN KEY (trade_id) REFERENCES public.trades(id) ON DELETE CASCADE;


--
-- Name: trade_reviews trade_reviews_reviewee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_reviews
    ADD CONSTRAINT trade_reviews_reviewee_id_fkey FOREIGN KEY (reviewee_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: trade_reviews trade_reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_reviews
    ADD CONSTRAINT trade_reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: trade_reviews trade_reviews_trade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_reviews
    ADD CONSTRAINT trade_reviews_trade_id_fkey FOREIGN KEY (trade_id) REFERENCES public.trades(id) ON DELETE CASCADE;


--
-- Name: trades trades_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trades
    ADD CONSTRAINT trades_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_contacts user_contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

